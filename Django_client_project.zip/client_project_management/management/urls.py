from django.urls import path
from . import views

urlpatterns = [
    path('clients/', views.ClientListCreateView.as_view(), name="client-list-create"),
    path('clients/<int:pk>/', views.ClientRetrieveUpdateDeleteView.as_view(), name="client-detail"),
    path('clients/<int:client_id>/projects/', views.ProjectListCreateView.as_view(), name="project-list-create"),
    path('projects/', views.ProjectListCreateView.as_view(), name="user-projects"),
]
